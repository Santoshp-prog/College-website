<?php 
    final class GalleryImage extends Database{
        use DataTraits;
        public function __construct()
        {
          parent::__construct();
          $this->table = 'gallery_images';
        }

        final public function getImagesByGallery($Gallery_id){
          $args = array(
            'where' => array(
              'gallery_id' => $Gallery_id
            )
          );
          return $this->select($args);
        }

        final public function deleteImageByName($image_name){
          $args = array(
            'where' => array(
              'image_name' => $image_name
            )
          );
          return $this->delete($args);
        }
    }
