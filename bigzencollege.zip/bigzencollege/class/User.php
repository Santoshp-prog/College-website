<?php 
    final class User extends Database{
        use DataTraits;
        public function __construct(){
            parent::__construct();
            $this->table = 'users';
        }

        public function getUserByEmail($email){
            $query = array(
                //'fields'=> 'id, status, email, role, name, password',
                'where' => array(
                    'email' => $email,
                    'status' => 'active'
                )
            );
            
            return $this->selectRow($query);
        }

        public function getUserByCookie($cookie_token){
            $query = array(
                'where' => array(
                    'remember_token' => $cookie_token,
                    'status' => 'active'
                )
            );
            return $this->selectRow($query);
        }

        public function getUserById($user_id){
            $query = array(
                'where' => array(
                    'id' => $user_id
                )
            );
            return $this->selectRow($query);

        }
    }