<?php

final class Portfolio extends Database
{
    use DataTraits;

    public function __construct()
    {
        parent::__construct();
        $this->table = 'portfolios';
    }
    public function getPortfolio()
    {
        $pdoQuery = "SELECT * FROM portfolios";
        $pdoQuery_run = $this->conn->query($pdoQuery);
        $pdoQuery_exec = $pdoQuery_run->rowCount();
        return $pdoQuery_exec;
    }
    public function getHomePortfolio($limit)
    {
        $query = array(
            'where' => array(
                'status' => 'active'
            ),
            'order_by' => 'id DESC',
            'limit' => '0, ' . $limit
        );
        return $this->selectRow($query);
    }
    public function getAllPortfolio(){
        $query = array(
            'where'=> array(
                'status'=>'active'
            ),
            'order_by' =>'id DESC',
                 
        );
        return $this->selectRow($query);
    }

}
