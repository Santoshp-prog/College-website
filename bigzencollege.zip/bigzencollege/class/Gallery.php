<?php
final class Gallery extends Database
{
    use DataTraits;
    public function __construct()
    {
        parent::__construct();
        $this->table = 'galleries';
    }
    public function getGallery()
    {
        $pdoQuery = "SELECT * FROM galleries";
        $pdoQuery_run = $this->conn->query($pdoQuery);
        $pdoQuery_exec = $pdoQuery_run->rowCount();
        return $pdoQuery_exec;
    }
    public function getAllGallery(){
        $query = array(
            'where'=> array(
                'status'=>'active'
            ),
            'order_by' =>'id DESC',
                 
        );
        return $this->selectRow($query);
    }

}
