<?php 
    final class Video extends Database{
        use DataTraits;

        public function __construct()
        {
            parent::__construct();
            $this->table = "videos";
        }
        public function getVideo()
    {
        $pdoQuery = "SELECT * FROM videos";
        $pdoQuery_run = $this->conn->query($pdoQuery);
        $pdoQuery_exec = $pdoQuery_run->rowCount();
        return $pdoQuery_exec;
    }
    
    public function getAllVideo(){
        $query = array(
            'where'=> array(
                'status'=>'active'
            ),
            'order_by' =>'id DESC',
                 
        );
        return $this->selectRow($query);
    }
    }
