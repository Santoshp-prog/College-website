<?php 

    final class Notice extends Database{
        use DataTraits;

        public function __construct()
        {
            parent::__construct();
            $this->table = 'notices';
        }
        public function getNotice()
        {
            $pdoQuery = "SELECT * FROM notices";
            $pdoQuery_run = $this->conn->query($pdoQuery);
            $pdoQuery_exec = $pdoQuery_run->rowCount();
            return $pdoQuery_exec;
        }
        public function getAllNotice(){
            $query = array(
                'where'=> array(
                    'status'=>'active'
                ),
                'order_by' =>'id DESC',
                     
            );
            return $this->selectRow($query);
        }
    }