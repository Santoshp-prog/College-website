<?php
final class Service extends Database
{
    use DataTraits;

    public function __construct()
    {
        parent::__construct();
        $this->table = 'services';
    }
    public function getService()
    {
        $pdoQuery = "SELECT * FROM services";
        $pdoQuery_run = $this->conn->query($pdoQuery);
        $pdoQuery_exec = $pdoQuery_run->rowCount();
        return $pdoQuery_exec;
    }

    public function getHomeService($limit){
        $query = array(
            'where'=> array(
                'status'=>'active'
            ),
            'order_by' =>'id DESC',
            'limit' =>'0, '.$limit      
        );
        return $this->selectRow($query);
    }
    public function getAllService(){
        $query = array(
            'where'=> array(
                'status'=>'active'
            ),
            'order_by' =>'id DESC',
                 
        );
        return $this->selectRow($query);
    }

}

