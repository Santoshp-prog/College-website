<?php
function debug($data, $is_exit = false)
{
    echo "<pre style='background: #FFFFFF;'>";
    print_r($data);
    echo "</pre>";
    if ($is_exit) {
        exit;
    }
}

function setSession($key, $value)
{
    if (!isset($_SESSION)) {
        session_start();
    }
    $_SESSION[$key] = $value;
}

function flash()
{
    if (isset($_SESSION['error']) && !empty($_SESSION['error'])) {
        echo "<p class='alert alert-danger'>" . $_SESSION['error'] . "</p>";
        unset($_SESSION['error']);
    }
    if (isset($_SESSION['success']) && !empty($_SESSION['success'])) {
        echo "<p class='alert alert-success'>" . $_SESSION['success'] . "</p>";
        unset($_SESSION['success']);
    }
}

function redirect($path, $session_key = null, $session_msg = null)
{
    if ($session_key !== null) {
        setSession($session_key, $session_msg);
    }
    header('location: ' . $path);
    exit;
}

function randomString($length = 100)
{
    $chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $len = strlen($chars);
    $random = "";
    for ($i = 0; $i < $length; $i++) {
        $random .= $chars[rand(0, $len - 1)];
    }
    return $random;
}

function sanitize($str)
{
    $str = strip_tags($str);
    $str = rtrim($str);

    return $str;
}

function uploadSingleImage($file, $dir_name)
{
    if ($file['error'] == 0) {
        if ($file['size'] <= 10240000) {
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);

            if (in_array(strtolower($ext), ALLOWED_EXTS)) {
                $upload_path = UPLOAD_DIR . "/" . $dir_name;
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0777, true);
                }
                // Service-20200912063465123.jpg
                $file_name = ucfirst($dir_name) . "-" . date('Ymdhis') . rand(0, 999) . "." . $ext;
                $success = move_uploaded_file($file['tmp_name'], $upload_path . "/" . $file_name);
                if ($success) {
                    return $file_name;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function getYouTubeVideoId($url)
{
    preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $url, $matches);
    return $matches[1];
}

function getCurrentUrl()
{
    //debug($_SERVER,true);
    return SITE_URL . $_SERVER['REQUEST_URI'];
}
