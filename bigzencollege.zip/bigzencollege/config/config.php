<?php
ob_start();
session_start();

/**Database Connection */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_NAME', 'dullu_college');
define('DB_PWD', '');
/**Database Connection */

//$url = "http://dullu.loc";
$url = $_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['HTTP_HOST'];

define('SITE_URL', $url);

define('SITE_TITLE', 'bigzensoft.com');

define('CMS_URL', SITE_URL . '/cms');

/**Admin Assets */
define('CMS_ASSETS', CMS_URL . '/assets');
define('CMS_CSS', CMS_ASSETS . '/css');
define('CMS_JS', CMS_ASSETS . '/js');
define('CMS_IMAGES', CMS_ASSETS . '/img');
define('CMS_PLUGINS', CMS_ASSETS . '/plugins');

define('ERROR_LOG', $_SERVER['DOCUMENT_ROOT'] . '/error/error.log');

define('ALLOWED_EXTS', array('jpg', 'jpeg', 'bmp', 'png', 'svg'));
define('UPLOAD_DIR', $_SERVER['DOCUMENT_ROOT'] . '/uploads');
define('UPLOAD_URL', SITE_URL . '/uploads');



/**Frontend Assets */
define('ASSETS_URL', SITE_URL . '/assets');
define('CSS_URL', ASSETS_URL . '/css');
define('JS_URL', ASSETS_URL . '/js');
define('IMAGES_URL', ASSETS_URL . '/img');
define('PLUGINS_URL', ASSETS_URL . '/plugins');

define('SITE_KEYWORDS', 'bigzen,Bigzen Soft Pvt.Ltd., engineering &IT hub in nepal, Software Company,IT training Centre, Software Company in Surkhet,IT Hub in Karnali Pardesh, Software in Nepal,Website design,website development,Billing System Software,Graphics Design,Domain Registration,Hosting Services,IT consultant,All types Of IT Related Work');
define('SITE_DESCRIPTION', 'Bigzen soft Ltd is IT hub and techonolgy center in Nepal,Bigzen Soft Pvt Ltd is the Leading software Company In Karnali Pardesh And all over Nepal,It is established in 2019 AD and running Smoothly In Capital Of Karnali Pardesh Nepal,Software Company for all types of It Solutions,Bigzen Soft. Pvt Ltd. was established on 2019. Its Head office is located in Birendranagar-3, Surkhet Nepal, During the short period of time bigzen has achieved a lot of success in the it field of Karnali Province
and it has been doing');