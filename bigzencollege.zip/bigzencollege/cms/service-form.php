<?php require '../config/init.php';
require 'inc/checklogin.php';
$service = new Service();

$act = "add";
if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
  $act = "update";
  $id = (int) $_GET['id'];
  if ($id <= 0) {
    redirect('../service.php', 'error', 'Invalid service id.');
  }

  $service_info = $service->getRowById($id);
  if (!$service_info) {
    redirect('../service.php', 'error', 'Service not found or has been already deleted.');
  }
  //debug($service_info);
}

?>
<?php require 'inc/header.php'; ?>

<!-- Page Wrapper -->
<div id="wrapper">

  <?php require 'inc/sidebar.php'; ?>
  <link rel="stylesheet" href="<?php echo CMS_PLUGINS . '/summernote/summernote-bs4.css' ?>">

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

      <?php require 'inc/top-nav.php'; ?>

      <!-- Begin Page Content -->
      <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">
          Service <?php echo ucfirst($act); ?>
        </h1>
        <div class="row">
          <div class="col-12">
            <form action="process/service.php" method="post" enctype="multipart/form-data" class="form">
              <div class="form-group row">
                <label for="" class="col-sm-3">Title:</label>
                <div class="col-sm-9">
                  <input type="text" value="<?php echo @$service_info[0]->title; ?>" name="title" required id="title" class="form-control form-control-sm" placeholder="Enter Service title...">
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3">Summary:</label>
                <div class="col-sm-9">
                  <textarea name="summary" id="summary" rows="5" style="resize:none;" class="form-control"><?php echo @$service_info[0]->summary; ?></textarea>
                </div>
              </div>
              
              <div class="form-group row">
                 <label for="" class="col-sm-3">Description: </label>
                 <div class="col-sm-9">
                 <textarea name="description" id="description" rows="5" style="resize: none" class="form-control"><?php echo html_entity_decode(@$service_info[0]->description);?></textarea>
                    </div>
                 </div>

              <div class="form-group row">
                <label for="" class="col-sm-3">Status:</label>
                <div class="col-sm-9">
                  <select name="status" required id="status" class="form-control form-control-sm">
                    <option value="active" <?php echo (isset($service_info) && $service_info[0]->status == 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (isset($service_info) && $service_info[0]->status == 'inactive') ? 'selected' : ''; ?>>In-Active</option>
                  </select>
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3">Image:</label>
                <div class="col-sm-5">
                  <input type="file" name="image" id="image" accept="image/*">
                </div>
                <div class="col-sm-4">
                  <?php
                  if (isset($service_info) && !empty($service_info[0]->image)) {
                  ?>
                    <img src="<?php echo UPLOAD_URL . '/service/' . $service_info[0]->image; ?>" alt="" class="img img-fluid img-thumbnail">
                  <?php
                  }
                  ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3"></label>
                <div class="col-sm-9">
                  <button type="submit" class="btn btn-success">
                    <i class="fa fa-paper-plane"></i>
                    Submit
                  </button>
                  <input type="hidden" name="service_id" value="<?php echo @$service_info[0]->id ?>">
                  <button type="reset" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                    Reset
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <?php require 'inc/copy.php'; ?>

  </div>
  <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->



<?php require 'inc/footer.php'; ?>
<script src="<?php echo CMS_PLUGINS . '/summernote/summernote-bs4.min.js' ?>"></script>
<script>
    $('#description').summernote({
        height: 200
    });
</script>
