<?php require '../config/init.php';
require 'inc/checklogin.php';

?>
<?php require 'inc/header.php'; ?>
<!-- Page Wrapper -->
<div id="wrapper">

    <?php require 'inc/sidebar.php'; ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <?php require 'inc/top-nav.php'; ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-4 text-gray-800">User Profile </h1>
                <div class="row">
                    <div class="col-sm-12">
                        <form method="post" action="process/profile.php" class="form">
                            <div class="form-group row">
                                <label for="" class="col-sm-3">Name:</label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" value="<?php echo $_SESSION['name'] ?>" class="form-control form-control-sm">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">Current Password:</label>
                                <div class="col-sm-9">
                                    <input type="password" name="current_password" class="form-control form-control-sm" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">New Password:</label>
                                <div class="col-sm-9">
                                    <input type="password" name="password" class="form-control form-control-sm" required id="password">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">Confirm Password:</label>
                                <div class="col-sm-9">
                                    <input type="password" name="re_password" class="form-control form-control-sm" required id="re_password">
                                    <span id="error_msg"></span>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3"></label>
                                <div class="col-sm-9">

                                    <button type="submit" id="submit" class="btn btn-success">
                                        <i class="fa fa-paper-plane"></i>submit
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <?php require 'inc/copy.php'; ?>

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->



<?php require 'inc/footer.php'; ?>

<script>
    $('#submit').attr('disabled', 'disabled');
    $('#re_password').keyup(function(e) {
        var password = $('#password').val();
        var re_password = $(this).val();

        if (password == re_password && password.length >= 8) {
            $('#error_msg').removeClass('alert-danger');
            $('#error_msg').html('');
            $('#submit').removeAttr('disabled', 'disabled');
        } else {
            $('#error_msg').addClass('alert-danger');
            $('#error_msg').html('Password and confirm password does not match.');
            $('#submit').attr('disabled', 'disabled');
        }
    });
</script>