<?php
require '../../config/init.php';
require '../inc/checklogin.php';
$video = new Video();


if (isset($_POST) && !empty($_POST)) {
    //debug($_POST);
    //debug($_FILES, true);
    $data = array(
        'title' => sanitize($_POST['title']),
        'status' => sanitize($_POST['status']),
        'link' => sanitize($_POST['link']),
        'added_by' => $_SESSION['user_id'],
    );
    $data['video_id'] = getYouTubeVideoId($_POST['link']);
    //debug($data , true);

    $video_id = (isset($_POST['video_id']) && !empty($_POST['video_id'])) ? (int) $_POST['video_id'] : null;
    //debug($video_id,true);
    if ($video_id) {
        $act = "updat";
        $status = $video->updateRow($data, $video_id);
    } else {
        $act = "add";
        $status = $video->insertData($data);
    }

    if ($status) {
        redirect('../video.php', 'success', 'Video ' . $act . 'ed Successfully!');
    } else {
        redirect('../video.php', 'error', 'Sorry! There was problem while adding video.');
    }
} else if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
    $id = (int) $_GET['id'];
    if ($id <= 0) {
        redirect('../video.php', 'error', 'Invalid video id.');
    }

    $video_info = $video->getRowById($id);
    if (!$video_info) {
        redirect('../video.php', 'error', 'Video not found or has been already deleted.');
    }

    $del = $video->deleteRowById($id);
    if ($del) {
        if ($video_info[0]->image != null && file_exists(UPLOAD_DIR . '/video/' . $video_info[0]->image)) {
            unlink(UPLOAD_DIR . '/video/' . $video_info[0]->image);
        }
        redirect('../video.php', 'success', 'Video deleted successfully.');
    } else {
        redirect('../video.php', 'error', 'Sorry! There was problem while deleting Video.');
    }
} else {
    redirect('../video.php', 'error', 'Add video first.');
}
