<?php
require '../../config/init.php';
require '../inc/checklogin.php';
$gallery = new Gallery();


if (isset($_POST) && !empty($_POST)) {
    //debug($_POST, true);
    //debug($_FILES, true);
    $data = array(
        'title' => sanitize($_POST['title']),
        'status' => sanitize($_POST['status']),
        'summary' => sanitize($_POST['summary']),
        'photographer' => sanitize($_POST['photographer']),
        'added_by' => $_SESSION['user_id'],
    );

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $file_name = uploadSingleImage($_FILES['image'], "gallery");
        if ($file_name) {
            $data['image'] = $file_name;
        }
    }
    //debug($data, true);

    $gallery_id = (isset($_POST['gallery_id']) && !empty($_POST['gallery_id'])) ? (int) $_POST['gallery_id'] : null;

    if (isset($_POST['del_image']) && !empty($_POST['del_image'])) {
        foreach ($_POST['del_image'] as $del_image) {
            $gal_image = new GalleryImage();
            $del = $gal_image->deleteImageByName($del_image);
            if ($del) {
                if (!empty($del_image) && file_exists(UPLOAD_DIR . '/gallery/' . $del_image)) {
                    unlink(UPLOAD_DIR . '/gallery/' . $del_image);
                }
            }
        }
    }




    if ($gallery_id) {
        $act =  "updat";
        $status = $gallery->updateRow($data, $gallery_id);
    } else {
        $act = "add";
        $status = $gallery->insertData($data);
    }

    if ($status) {
        if (isset($_FILES['related_images']) && !empty($_FILES['related_images'])) {
            $files = $_FILES['related_images'];
            $count = count($files['name']);
            for ($i = 0; $i < $count; $i++) {
                $temp = array(
                    'name' => $files['name'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i],
                    'type' => $files['type'][$i],
                );

                $success = uploadSingleImage($temp, 'gallery');
                if ($success) {
                    $temp_data = array(
                        'gallery_id' => $status,
                        'image_name' => $success,
                    );
                    $image = new GalleryImage();
                    $image->insertData($temp_data);
                }
            }
        }

        redirect('../gallery.php', 'success', 'Gallery ' . $act . 'ed successfull!');
    } else {
        redirect('../gallery.php', 'error', 'Sorry! There was a problem while adding gallery.');
    }
} else if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
    $id = (int) $_GET['id'];
    if ($id <= 0) {
        redirect('../gallery.php', 'error', 'Invalid Gallery id.');
    }

    $gallery_info = $gallery->getRowByID($id);
    $gallery_image = new GalleryImage;
    $all_images = $gallery_image->getImagesByGallery($id);

    if (!$gallery_info) {
        redirect('../gallery.php', 'error', 'Gallery not found or has been already deleted.');
    }

    $del = $gallery->deleteRowById($id);

    if ($del) {
        if ($gallery_info[0]->image != null && file_exists(UPLOAD_DIR . '/gallery/' . $gallery_info[0]->image)) {
            unlink(UPLOAD_DIR . '/gallery/' . $gallery_info[0]->image);

            if ($all_images) {
                foreach ($all_images as $del_image_name) {
                    unlink(UPLOAD_DIR . '/gallery/' . $del_image_name->image_name);
                }
            }
        }
        redirect('../gallery.php', 'success', 'Gallery deleted successfull.');
    } else {
        redirect('../gallery.php', 'error', 'Sorry! There was problem while deleting gallery.');
    }
} else {
    redirect('../gallery.php', 'error', 'Add gallery first.');
}
