<?php
require_once "../../config/init.php";
require_once "../inc/checklogin.php";
$user = new User();

if (isset($_POST, $_POST['current_password'], $_POST['password'], $_POST['re_password']) && !empty($_POST['current_password']) && !empty($_POST['password']) && !empty($_POST['re_password']) && !empty($_POST)) {

    if ($_POST['password'] != $_POST['re_password']) {
        redirect('../profile.php', 'error', 'Confirm password does not match.');
    }
    debug($_POST);

    $curren_password = sha1($_SESSION['email'] . $_POST['current_password']);
    $user_info = $user->getUserById($_SESSION['user_id']);

    if ($user_info[0]->password != $curren_password) {
        redirect('../profile.php', 'error', 'Old password does not match.');
    }

    $new_password = sha1($_SESSION['email'] . $_POST['password']);
    $data = array(
        'password' => $new_password
    );

    $status = $user->updateRow($data, $_SESSION['user_id']);

    if ($status) {
        redirect('../logout.php');
    } else {
        redirect('../profile.php', 'error', 'Sorry! Password could not be updated at this moment. Please contact our administration');
    }
} else {
    redirect('../profile.php', 'error', 'please fill the form first.');
}
