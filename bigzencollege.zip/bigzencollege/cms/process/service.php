<?php
require '../../config/init.php';
require '../inc/checklogin.php';
$service = new Service();


if (isset($_POST) && !empty($_POST)) {
    //debug($_POST);
    //debug($_FILES, true);
    $data = array(
        'title' => sanitize($_POST['title']),
        'status' => sanitize($_POST['status']),
        'summary' => sanitize($_POST['summary']),
        'description' =>htmlentities($_POST['description']),
        'added_by' => $_SESSION['user_id'],
    );

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $file_name = uploadSingleImage($_FILES['image'], "service");
        if ($file_name) {
            $data['image'] = $file_name;
        }
    }

    $service_id = (isset($_POST['service_id']) && !empty($_POST['service_id'])) ? (int) $_POST['service_id'] : null;
    if ($service_id) {
        $act = "updat";
        $status = $service->updateRow($data, $service_id);
    } else {
        $act = "add";
        $status = $service->insertData($data);
    }

    if ($status) {
        redirect('../service.php', 'success', 'Service ' . $act . 'ed Successfully!');
    } else {
        redirect('../service.php', 'error', 'Sorry! There was problem while adding service.');
    }
} else if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
    $id = (int) $_GET['id'];
    if ($id <= 0) {
        redirect('../service.php', 'error', 'Invalid service id.');
    }

    $service_info = $service->getRowById($id);
    if (!$service_info) {
        redirect('../service.php', 'error', 'Service not found or has been already deleted.');
    }

    $del = $service->deleteRowById($id);
    if ($del) {
        if ($service_info[0]->image != null && file_exists(UPLOAD_DIR . '/service/' . $service_info[0]->image)) {
            unlink(UPLOAD_DIR . '/service/' . $service_info[0]->image);
        }
        redirect('../service.php', 'success', 'Service deleted successfully.');
    } else {
        redirect('../service.php', 'error', 'Sorry! There was problem while deleting Service.');
    }
} else {
    redirect('../service.php', 'error', 'Add service first.');
}
