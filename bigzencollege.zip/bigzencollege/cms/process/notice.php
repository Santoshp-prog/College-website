<?php
require '../../config/init.php';
require '../inc/checklogin.php';
$notice = new Notice();


if (isset($_POST) && !empty($_POST)) {
    //debug($_POST);
    //debug($_FILES, true);
    $data = array(
        'title' => sanitize($_POST['title']),
        'status' => sanitize($_POST['status']),
        'description'=> htmlentities($_POST['description']),
        'added_by' => $_SESSION['user_id'],
    );

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $file_name = uploadSingleImage($_FILES['image'], "notice");
        if ($file_name) {
            $data['image'] = $file_name;
        }
    }

    $notice_id = (isset($_POST['notice_id']) && !empty($_POST['notice_id'])) ? (int) $_POST['notice_id'] : null;
    if ($notice_id) {
        $act = "updat";
        $status = $notice->updateRow($data, $notice_id);
    } else {
        $act = "add";
        $status = $notice->insertData($data);
    }

    if ($status) {
        redirect('../notice.php', 'success', 'notice ' . $act . 'ed Successfully!');
    } else {
        redirect('../notice.php', 'error', 'Sorry! There was problem while adding notice.');
    }
} else if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
    $id = (int) $_GET['id'];
    if ($id <= 0) {
        redirect('../notice.php', 'error', 'Invalid notice id.');
    }

    $notice_info = $notice->getRowById($id);
    if (!$notice_info) {
        redirect('../notice.php', 'error', 'notice not found or has been already deleted.');
    }

    $del = $notice->deleteRowById($id);
    if ($del) {
        if ($notice_info[0]->image != null && file_exists(UPLOAD_DIR . '/notice/' . $notice_info[0]->image)) {
            unlink(UPLOAD_DIR . '/notice/' . $notice_info[0]->image);
        }
        redirect('../notice.php', 'success', 'notice deleted successfully.');
    } else {
        redirect('../notice.php', 'error', 'Sorry! There was problem while deleting notice.');
    }
} else {
    redirect('../notice.php', 'error', 'Add notice first.');
}
