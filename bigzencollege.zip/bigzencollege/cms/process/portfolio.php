<?php
require '../../config/init.php';
require '../inc/checklogin.php';
$portfolio = new Portfolio();


if (isset($_POST) && !empty($_POST)) {
    //debug($_POST);
    //debug($_FILES, true);
    $data = array(
        'title' => sanitize($_POST['title']),
        'status' => sanitize($_POST['status']),
        'description'=> htmlentities($_POST['description']),
        'added_by' => $_SESSION['user_id'],
    );

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $file_name = uploadSingleImage($_FILES['image'], "portfolio");
        if ($file_name) {
            $data['image'] = $file_name;
        }
    }

    $portfolio_id = (isset($_POST['portfolio_id']) && !empty($_POST['portfolio_id'])) ? (int) $_POST['portfolio_id'] : null;
    if ($portfolio_id) {
        $act = "updat";
        $status = $portfolio->updateRow($data, $portfolio_id);
    } else {
        $act = "add";
        $status = $portfolio->insertData($data);
    }

    if ($status) {
        redirect('../portfolio.php', 'success', 'portfolio ' . $act . 'ed Successfully!');
    } else {
        redirect('../portfolio.php', 'error', 'Sorry! There was problem while adding portfolio.');
    }
} else if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
    $id = (int) $_GET['id'];
    if ($id <= 0) {
        redirect('../portfolio.php', 'error', 'Invalid portfolio id.');
    }

    $portfolio_info = $portfolio->getRowById($id);
    if (!$portfolio_info) {
        redirect('../portfolio.php', 'error', 'portfolio not found or has been already deleted.');
    }

    $del = $portfolio->deleteRowById($id);
    if ($del) {
        if ($portfolio_info[0]->image != null && file_exists(UPLOAD_DIR . '/portfolio/' . $portfolio_info[0]->image)) {
            unlink(UPLOAD_DIR . '/portfolio/' . $portfolio_info[0]->image);
        }
        redirect('../portfolio.php', 'success', 'portfolio deleted successfully.');
    } else {
        redirect('../portfolio.php', 'error', 'Sorry! There was problem while deleting portfolio.');
    }
} else {
    redirect('../portfolio.php', 'error', 'Add portfolio first.');
}
