<?php require '../config/init.php';
require 'inc/checklogin.php';
$video = new Video();

$act = "add";
if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
  $act = "update";
  $id = (int) $_GET['id'];
  if ($id <= 0) {
    redirect('../video.php', 'error', 'Invalid video id.');
  }

  $video_info = $video->getRowById($id);
  if (!$video_info) {
    redirect('../video.php', 'error', 'Video not found or has been already deleted.');
  }
  //debug($video_info);
}

?>
<?php require 'inc/header.php'; ?>
<!-- Page Wrapper -->
<div id="wrapper">

  <?php require 'inc/sidebar.php'; ?>

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

      <?php require 'inc/top-nav.php'; ?>

      <!-- Begin Page Content -->
      <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">
          Video <?php echo ucfirst($act); ?>
        </h1>
        <div class="row">
          <div class="col-12">
            <form action="process/video.php" method="post" enctype="multipart/form-data" class="form">
              <div class="form-group row">
                <label for="" class="col-sm-3">Title:</label>
                <div class="col-sm-9">
                  <input type="text" value="<?php echo @$video_info[0]->title; ?>" name="title" required id="title" class="form-control form-control-sm" placeholder="Enter video title...">
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3">URL (YouTube)</label>
                <div class="col-sm-9">
                  <input type="url" value="<?php echo @$video_info[0]->link; ?>" name="link" required id="link" class="form-control form-control-sm" placeholder="Enter video link...">
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3">Status:</label>
                <div class="col-sm-9">
                  <select name="status" required id="status" class="form-control form-control-sm">
                    <option value="active" <?php echo (isset($video_info) && $video_info[0]->status == 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (isset($video_info) && $video_info[0]->status == 'inactive') ? 'selected' : ''; ?>>In-Active</option>
                  </select>
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3"></label>
                <div class="col-sm-9">
                  <input type="hidden" name="video_id" value="<?php echo @$video_info[0]->id ?>">
                    <button type="submit" class="btn btn-success">
                    <i class="fa fa-paper-plane"></i>
                    Submit
                  </button>
                  <button type="reset" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                    Reset
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <?php require 'inc/copy.php'; ?>

  </div>
  <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->



<?php require 'inc/footer.php'; ?>