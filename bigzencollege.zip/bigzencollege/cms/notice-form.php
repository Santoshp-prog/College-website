<?php require '../config/init.php';
require 'inc/checklogin.php';
$notice = new Notice();

$act = "add";
if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
  $act = "update";
  $id = (int) $_GET['id'];
  if ($id <= 0) {
    redirect('../notice.php', 'error', 'Invalid notice id.');
  }

  $notice_info = $notice->getRowById($id);
  if (!$notice_info) {
    redirect('../notice.php', 'error', 'notice not found or has been already deleted.');
  }
  //debug($notice_info);
}

?>
<?php require 'inc/header.php'; ?>

<!-- Page Wrapper -->
<div id="wrapper">

  <?php require 'inc/sidebar.php'; ?>
  <link rel="stylesheet" href="<?php echo CMS_PLUGINS . '/summernote/summernote-bs4.css' ?>">

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

      <?php require 'inc/top-nav.php'; ?>

      <!-- Begin Page Content -->
      <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">
          Notice <?php echo ucfirst($act); ?>
        </h1>
        <div class="row">
          <div class="col-12">
            <form action="process/notice.php" method="post" enctype="multipart/form-data" class="form">
              <div class="form-group row">
                <label for="" class="col-sm-3">Title:</label>
                <div class="col-sm-9">
                  <input type="text" value="<?php echo @$notice_info[0]->title; ?>" name="title" required id="title" class="form-control form-control-sm" placeholder="Enter notice title...">
                </div>
              </div>
              <div class="form-group row">
                 <label for="" class="col-sm-3">Description: </label>
                 <div class="col-sm-9">
                 <textarea name="description" id="description" rows="5" style="resize: none" class="form-control"><?php echo html_entity_decode(@$notice_info[0]->description);?></textarea>
                    </div>
                 </div>

              <div class="form-group row">
                <label for="" class="col-sm-3">Status:</label>
                <div class="col-sm-9">
                  <select name="status" required id="status" class="form-control form-control-sm">
                    <option value="active" <?php echo (isset($notice_info) && $notice_info[0]->status == 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (isset($notice_info) && $notice_info[0]->status == 'inactive') ? 'selected' : ''; ?>>In-Active</option>
                  </select>
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3">Image:</label>
                <div class="col-sm-5">
                  <input type="file" name="image" id="image" accept="image/*">
                </div>
                <div class="col-sm-4">
                  <?php
                  if (isset($notice_info) && !empty($notice_info[0]->image)) {
                  ?>
                    <img src="<?php echo UPLOAD_URL . '/notice/' . $notice_info[0]->image; ?>" alt="" class="img img-fluid img-thumbnail">
                  <?php
                  }
                  ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="" class="col-sm-3"></label>
                <div class="col-sm-9">
                  <button type="submit" class="btn btn-success">
                    <i class="fa fa-paper-plane"></i>
                    Submit
                  </button>
                  <input type="hidden" name="notice_id" value="<?php echo @$notice_info[0]->id ?>">
                  <button type="reset" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                    Reset
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <?php require 'inc/copy.php'; ?>

  </div>
  <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->



<?php require 'inc/footer.php'; ?>
<script src="<?php echo CMS_PLUGINS . '/summernote/summernote-bs4.min.js' ?>"></script>
<script>
    $('#description').summernote({
        height: 200
    });
</script>
