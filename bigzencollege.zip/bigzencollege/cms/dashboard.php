<?php require '../config/init.php';
require 'inc/checklogin.php';

?>
<?php require 'inc/header.php'; ?>
<!-- Page Wrapper -->
<div id="wrapper">

  <?php require 'inc/sidebar.php'; ?>

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

      <?php require 'inc/top-nav.php'; ?>

      <!-- Begin Page Content -->
      <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="text-center">Dullu College Dashboard</h1>
        <hr>
        <div class="row">
          <div class="col-md-12">
            <div class="row">

              <div class="col-sm-4">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Services</h5>
                    <?php
                    $service = new Service();
                    $service_id = $service->getService();
                    ?>
                    <p class="card-text"><?php echo "Total Services: $service_id"; ?></p>
                    <?php
                    ?>
                    <a href="service.php" class="btn btn-primary">view-detail</a>
                  </div>
                </div>
              </div>

              <div class="col-sm-4">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Portfolios</h5>
                    <?php
                    $portfolio = new Portfolio();
                    $portfolio_id = $portfolio->getPortfolio();
                    ?>
                    <p class="card-text"><?php echo "Total portfolios: $portfolio_id"; ?></p>
                    <?php
                    ?>
                    <a href="portfolio.php" class="btn btn-primary">view-detail</a>
                  </div>
                </div>
              </div>

              <div class="col-sm-4">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Notice</h5>
                    <?php
                    $notice = new Notice();
                    $notice_id = $notice->getNotice();
                    ?>
                    <p class="card-text"><?php echo "Total notices: $notice_id"; ?></p>
                    <?php
                    ?>
                    <a href="notice.php" class="btn btn-primary">view-detail</a>
                  </div>
                </div>
              </div>

              <br>

              <div class="col-sm-4">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Gallery</h5>
                    <?php
                    $gallery = new gallery();
                    $gallery_id = $gallery->getGallery();
                    ?>
                    <p class="card-text"><?php echo "Total galleries: $gallery_id"; ?></p>
                    <?php
                    ?>
                    <a href="gallery.php" class="btn btn-primary">view-detail</a>
                  </div>
                </div>
              </div>



              <div class="col-sm-4">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Video</h5>
                    <?php
                    $video = new Video();
                    $video_id = $video->getVideo();
                    ?>
                    <p class="card-text"><?php echo "Total videos: $video_id"; ?></p>
                    <?php
                    ?>
                    <a href="video.php" class="btn btn-primary">view-detail</a>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div>

          </div>



        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->



    </div>
    <!-- End of Content Wrapper -->
    <?php require 'inc/copy.php'; ?>

  </div>
  <!-- End of Page Wrapper -->



  <?php require 'inc/footer.php'; ?>