<?php require '../config/init.php';
require 'inc/checklogin.php';

?>
<?php require 'inc/header.php'; ?>
<link rel="stylesheet" href="<?php echo CMS_CSS . '/datatables.min.css'; ?>">
<!-- Page Wrapper -->
<div id="wrapper">

  <?php require 'inc/sidebar.php'; ?>

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

      <?php require 'inc/top-nav.php'; ?>

      <!-- Begin Page Content -->
      <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">
          portfolio List
          <a href="portfolio-form.php" class="btn btn-success float-right">
            <i class="fa fa-plus"></i>Add portfolio
          </a>
        </h1>
        <hr>
        <div class="row">
          <div class="col-12">
            <table class="table">
              <thead class="thead-dark">
                <th>S.N.</th>
                <th>Title</th>
                <th>Status</th>
                <th>Image</th>
                <th>Action</th>
              </thead>
              <tbody>
                <?php
                $portfolio = new portfolio();
                $portfolio_all = $portfolio->getAllRows();
                if ($portfolio_all) {
                  foreach ($portfolio_all as $key => $portfolio_data) {
                ?>
                    <tr>
                      <td><?php echo $key + 1; ?></td>
                      <td><?php echo  $portfolio_data->title; ?></td>
                      <td>
                        <span class="badge badge-<?php echo ($portfolio_data->status == 'active') ? 'success' : 'danger' ?>">
                          <?php echo  ucfirst($portfolio_data->status); ?>
                        </span>
                      </td>
                      <td>
                        <?php
                        if ($portfolio_data->image != "") {
                        ?>
                          <img src="<?php echo UPLOAD_URL . '/portfolio/' . $portfolio_data->image; ?>" alt="" class="img img-fluid img-thumbnail" style="max-width: 50px;">
                        <?php
                        } else {
                          echo "No-Image";
                        }
                        ?>
                      </td>
                      <td>
                        <a href="portfolio-form.php?id=<?php echo $portfolio_data->id ?>" class="btn btn-success btn-circle">
                          <i class="fa fa-edit"></i>
                        </a>
                        <a href="process/portfolio.php?id=<?php echo $portfolio_data->id ?>" onclick="return confirm('Are you sure want to delete this portfolio?')" class="btn btn-danger btn-circle">
                          <i class="fa fa-trash"></i>
                        </a>
                      </td>
                    </tr>
                <?php
                  }
                }

                ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <?php require 'inc/copy.php'; ?>

  </div>
  <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->



<?php require 'inc/footer.php'; ?>
<script src="<?php echo CMS_JS . '/datatables.min.js'; ?>"></script>
<script>
  $('.table').DataTable();
</script>