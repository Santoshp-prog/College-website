<?php require '../config/init.php';
require 'inc/checklogin.php';
$gallery = new Gallery();

$act = "add";
if (isset($_GET, $_GET['id']) && !empty($_GET['id'])) {
    $act = "update";
    $id = (int) $_GET['id'];
    if ($id <= 0) {
        redirect('../gallery.php', 'error', 'Invalid Gallery id.');
    }
    $gallery_info = $gallery->getRowByID($id);
    if (!$gallery_info) {
        redirect('../gallery.php', 'error', 'Gallery not found or has been already deleted.');
    }
}

?>
<?php require 'inc/header.php'; ?>

<!-- Page Wrapper -->
<div id="wrapper">

    <?php require 'inc/sidebar.php'; ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <?php require 'inc/top-nav.php'; ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-4 text-gray-800">
                    Gallery <?php echo ucfirst($act) ?>
                </h1>
                <div class="row">
                    <div class="col-12">
                        <form action="process/gallery.php" method="post" enctype="multipart/form-data" class="form">
                            <div class="form-group row">
                                <label for="" class="col-sm-3">Title:</label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo @$gallery_info[0]->title; ?>" name="title" required id="title" placeholder="Enter Gallery Title.." class="form-control form-control-sm">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">Summary:</label>
                                <div class="col-sm-9">
                                    <textarea name="summary" id="summary" rows="5" style="resize:none;" class="form-control"><?php echo @$gallery_info[0]->summary; ?></textarea>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">Status:</label>
                                <div class="col-sm-9">
                                    <select name="status" required id="status" class="form-control form-control-sm">
                                        <option value="active" <?php echo (isset($gallery_info) && $gallery_info[0]->status == 'active') ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo (isset($gallery_info) && $gallery_info[0]->status == 'inactive') ? 'selected' : ''; ?>>In-Active</option>

                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">Photographer:</label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo @$gallery_info[0]->photographer; ?>" name="photographer" required id="photographer" placeholder="Enter Photographer Name.." class="form-control form-control-sm">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">Cover Image:</label>
                                <div class="col-sm-5">
                                    <input type="file" name="image" accept="image/*">
                                </div>
                                <div class="col-sm-4">
                                    <?php
                                    if (isset($gallery_info) && !empty($gallery_info[0]->image)) {
                                    ?>
                                        <img src="<?php echo UPLOAD_URL . '/gallery/' . $gallery_info[0]->image; ?>" alt="" class="img img-fluid img-thumbnail">
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-sm-3">Other Images:</label>
                                <div class="col-sm-9">
                                    <input type="file" name="related_images[]" multiple accept="image/*">
                                </div>
                            </div>
                            <?php
                            if ($act == 'update') {
                                $gallery_image = new GalleryImage();
                                $images = $gallery_image->getImagesByGallery($id);
                                if ($images) {
                            ?>
                                    <div class="row">
                                        <?php
                                        foreach ($images as $gal_image) {
                                        ?>
                                            <div class="col-sm-3">
                                                <img src="<?php echo UPLOAD_URL . '/gallery/' . $gal_image->image_name ?>" alt="" class="img img-fluid img-thumbnail">
                                                <input type="checkbox" name="del_image[]" value="<?php echo $gal_image->image_name ?>">Delete
                                            </div>
                                        <?php
                                        }
                                        ?>
                                    </div>
                            <?php
                                }
                            }
                            ?>

                            <div class="form-group row">
                                <label for="" class="col-sm-3"></label>
                                <div class="col-sm-9">
                                    <input type="hidden" name="gallery_id" value="<?php echo @$gallery_info[0]->id ?>">
                                     </button>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fa fa-paper-plane"></i>
                                        Submit
                                    </button>
                                    <button type="reset" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>
                                        Reset
                                </div>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <?php require 'inc/copy.php'; ?>

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->



<?php require 'inc/footer.php'; ?>