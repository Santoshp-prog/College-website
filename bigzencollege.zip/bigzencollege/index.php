<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="assets/img/deuti logo.png" type="image/png">
        <title>Bigzen College </title>

		<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="assets/vendors/linericon/style.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/vendors/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/vendors/lightbox/simpleLightbox.css">
        <link rel="stylesheet" href="assets/vendors/nice-select/css/nice-select.css">
        <link rel="stylesheet" href="assets/vendors/animate-css/animate.css">
        <link rel="stylesheet" href="assets/vendors/popup/magnific-popup.css">
        <!-- main css -->
        <link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" href="assets/css/responsive.css">
		<link rel="stylesheet" href="assets/css/counter.css">
		<link rel="stylesheet" href="assets/css/testimonials.css">
		<link rel="stylesheet" href="assets/slick/slick.css">
		<link rel="stylesheet" href="assets/css/courses.css">
		<link rel="stylesheet" href="assets/css/slick.css">
    </head>
    <body>
        
        <!--Header Menu Area -->
        <header class="header_area">
           	<div class="top_menu row m0">
           		<div class="container">
					<div class="float-left">
						<ul class="list header_social">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-envelope"></i></a></li>
							
						</ul>
					</div>
					<div class="float-right">
						<a class="dn_btn" href="tel:+977 083 521586"><i class="fa fa-phone"> 083-521586 </i></a>
						<a class="dn_btn" href="#"><i class="fa fa-map-marker">Birendranagar-03, Surkhet</i></a>
					</div>
           		</div>	
           	</div>	
            <div class="main_menu">
            	<nav class="navbar navbar-expand-lg navbar-light">
					<div class="container">
						<!-- Brand and toggle get grouped for better mobile display -->
						<a class="navbar-brand logo_h" href="index.php"><img src="assets/img/deuti logo.png" alt=""></a>
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
							<ul class="nav navbar-nav menu_nav ml-auto">
								<li class="nav-item active"><a class="nav-link" href="index.php">Home</a></li> 
								<li class="nav-item submenu dropdown">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About Us</a>
									<ul class="dropdown-menu">
										<li class="nav-item"><a class="nav-link" href="about-us.php">About Us</a></li>
										<li class="nav-item"><a class="nav-link" href="mdm.php">Message from Director</a></li>
										<li class="nav-item"><a class="nav-link" href="principalmessage.php">Message From Principal</a>
											
											<li class="nav-item"><a class="nav-link" href="academicteam.php">Academic Team</a></li>
											<li class="nav-item"><a class="nav-link" href="missionvision.php"> Mission/ Vision</a>
											
												
									</ul>
								</li> 
								<li class="nav-item submenu dropdown">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Courses</a>
									<ul class="dropdown-menu">
										<li class="nav-item"><a class="nav-link" href="courses.php">Courses</a>
										
									</ul>
								</li> 
								<li class="nav-item submenu dropdown">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Facilities</a>
									<ul class="dropdown-menu">
										
										<li class="nav-item"><a class="nav-link" href="facilities.php">Student Facilities</a></li>
										<li class="nav-item"><a class="nav-link" href="">ACA</a></li>
										
									</ul>
								</li> 
								
								<li class="nav-item submenu dropdown">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Extra</a>
									<ul class="dropdown-menu">
										<li class="nav-item"><a class="nav-link" href="newsnotice.php">Notice</a></li>
										<li class="nav-item"><a class="nav-link" href="">Downloads</a></li>
									</ul>
								</li> 
							
								<li class="nav-item submenu dropdown">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Gallery/Videos</a>
									<ul class="dropdown-menu">
										<li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
										<li class="nav-item"><a class="nav-link" href="video.php">Videos</a></li>
									</ul>
								</li> 
								<li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
							</ul>
						</div> 
					</div>
            	</nav>
            </div>
        </header>
        <!--================Header Menu Area =================-->
        
        <!-- slider section start -->
		
		<div id="slider" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
			  <!-- <li data-target="#slider" data-slide-to="0" class="active"></li>
			  <li data-target="#slider" data-slide-to="1"></li>
			  <li data-target="#slider" data-slide-to="2"></li> -->
			</ol>
			<div class="carousel-inner">
			  <div class="carousel-item active">
				<img src="assets/img/slider11.png" class="d-block w-100" alt="...">
				<div class="carousel-caption text-center">
					<h5>The roots of education are bitter, but the fruit is sweet</h5>
					 <a href="onlineadmissionform.php" class="btn ">Apply for Admission</a>
				  </div>
			  </div>
			  <div class="carousel-item">
				<img src="assets/img/slider22.png" class="d-block w-100" alt="...">
				<div class="carousel-caption text-center">
					<h5>“Teachers can open the door, but you must enter it yourself.” </h5>
					 <a href="onlineadmissionform.php" class="btn ">Apply for Admission</a>
				  </div>
			  </div>
			  <div class="carousel-item">
				<img src="assets/img/slider11.png" class="d-block w-100" alt="...">
				<div class="carousel-caption text-center">
					<h5>The mind is not a vessel to be filled but a fire to be ignited.”</h5>
					 <a href="onlineadmissionform.php" class="btn ">Apply for Admission</a>
				  </div>
			  </div>
			</div>
			<a class="carousel-control-prev" href="#slider" role="button" data-slide="prev">
			  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
			  <span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#slider" role="button" data-slide="next">
			  <span class="carousel-control-next-icon" aria-hidden="true"></span>
			  <span class="sr-only">Next</span>
			</a>
		  </div>


		  <!-- Slider Section css start -->


		<!-- Online Registration section start -->
		<section class="onlinereg">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="oncontent">
							<h5>Apply Of Online Registration</h5>
						</div>
					</div>
					<div class="col-md-3">
						<a href="#" class="register">Apply</a>
					</div>
				</div>
			</div>
		</section>
		<!-- Online registration section end -->
		


		<!-- welcome college section start -->

		<div class="welcomecollege">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<h2>WelCome To</h2>
						<h3>Bigzen College</h3>
						<div class="welcome-section">
							<p><b style="color:  #39418a; font-size: 22px;"> Surkhet Model College</b> Education is the process of facilitating learning, or the acquisition of knowledge,
								 skills, values, beliefs, and habits. Educational methods include teaching, training,
								  storytelling, discussion and directed research. Education frequently takes place under
								   the guidance of educators, 
								
								however learners can also educate themselves. <br>
								Education is the process of facilitating learning, or the acquisition of knowledge,
								 skills, values, beliefs, and habits. Educational methods include teaching, training,
								  storytelling, discussion and directed research. Education frequently takes place under
								   the guidance of educators, 
								however learners can also educate themselves.
							</p>
							<div class="smore">
								<a href="about-us.php">Know More</a>
							</div>
						</div>
					</div>
					<div class="col-md-4 collimg">

						<img src="assets/img/college.jpg" alt="">
						
					</div>
				</div>
			</div>
		</div>


		<!-- welcome College Section end -->

		
		
		<!-- Management team section start -->

		<section class="management section" id="managementid">
			
			<div class="container">
			
				<div class="section-title" style="text-align: center;">
					<h2>Our Management Team</h2>
					<p>WIth great expertise in their respective subjects, we have a dynamic and energetic 
						team of very experienced teachers 
						who can ensure the delivery of best possible practical knowledge.</p>
				</div>
				<div class="row">
	
					<!-- management item start -->
					<div class="management-item ">
						<div class="management-item-inner shadow-dark">
						  <div class="management-img">
							<img src="assets/img/santu.jpg" alt="">
							<!-- <div class="managementwhat">Building</div> -->
						  </div>
						  <div class="management-info">
							<a href="">
								<h4 class="management-title">Mr. Santosh Pandeya</h4>
								<h5 class="management-post">Principal</h5>
							</a>
							  							   
						  </div>
					  </div>
					</div>
					<!-- management item end -->
					 <!-- management item start -->
					 <div class="management-item ">
						<div class="management-item-inner shadow-dark">
							<div class="management-img">
							  <img src="assets/img/santu.jpg" alt="">
							  <!-- <div class="managementwhat">Shopping Mall</div> -->
							</div>
							<div class="management-info">
								<a href="">
									<h4 class="management-title">Mr. Santosh Pandeya</h4>
									<h5 class="management-post">Principal</h5>
								</a>
																
							</div>
						</div>
					  </div>
					  <!-- management item end -->
		
					   <!-- management item start -->
					<div class="management-item">
						<div class="management-item-inner shadow-dark">
							<div class="management-img">
							  <img src="assets/img/santu.jpg" alt="">
							  <!-- <div class="managementwhat">Complex Mall</div> -->
							</div>
							<div class="management-info">
								<a href="">
								<h4 class="management-title">Mr. Santosh Pandeya</h4>
								<h5 class="management-post">Principal</h5>
							</a>
								
							</div>
						</div>
					  </div>
					  <!-- management item end -->
	
					  <!-- management item start -->
					<div class="management-item">
						<div class="management-item-inner shadow-dark">
							<div class="management-img">
							  <img src="assets/img/santu.jpg" alt="">
							  <!-- <div class="managementwhat">Complex Mall</div> -->
							</div>
							<div class="management-info">
								<a href="">
									<h4 class="management-title">Mr. Santosh Pandeya</h4>
									<h5 class="management-post">Principal</h5>
								</a>
																
							</div>
						</div>
					  </div>
					  <!-- management item end -->
				</div>
			</div>
		</section>
		<!-- Management team section end -->


		<!-- Message From Chairman section start -->

	

	


		<section class="recent-update">
			<div class="container">
			  <div class="row">
		
				<div class="col-md-8 col-sm-12 col-xs-12">
				  <div class="recent-update-left">
					<main>
					<div class="mainleft">
					  <h2><b style="color: #247a92;"> Message From </b> <span> Managing Director </span></h2>
					  <p> <b style="color: #FCB040;"> Welcome !! </b> to the world of New Rara Engineering Consultancy and Research Centre (P) Ltd.
						I would like to express my heartfelt gratitude to our esteemed clientele, financers, bankers and also to record my sincere appreciation for the employees who work diligently and deliver the projects to everyone’s delight. Further, I would also like to thank you all for visiting our profile and learning about our Victorious Voyage in the consultancy business.
						It is the first digital engineering consultancy at Karnali State. It provides consulting services in the field of civil and structure engineering with strong commitment of our people to service, quality and teamwork.
						 we have been able to successfully accomplish a wide variety of projects in Nepal. <a href="mdm.php" style="color: teal;">See More</a>
						
						</p>
					</div>
				  
					<div class="mainright">
					  <img src="assets/img/santu.jpg" alt="Santosh" class="img img-fluid img-thumbnail" />
					  <p>
						<h3 style="color: #247a92; font-size: 18px;">Er. Santosh Pandeya</h3>
						<!-- <h3 style="color: #fcb040; font-size: 14px;"><strong>New Rara Engineering Consultancy And Research Center</strong></h3> -->
					  </p>
					</div>
					<div class="clear"></div>
					<!--chairman end-->
		
				  </main>
					
				   
				  </div>
				  
				</div>
		
				<div class="col-md-4 col-sm-12 col-xs-12">
		
				  <div class="recent-update-right">
					<div class="title">
					  <p>Notice</p>
					  <h2>Latest News</h2>
					</div>
					<div class="info-list">
					  <ul>
						<li><a href="noticedesc.php"> <i class="fa fa-newspaper-o"></i>"Why Bigzen soft"</a>
						  <span>Posted on: August 30,2020</span></li>
		
						  <li><a href="noticedesc.php"> <i class="fa fa-newspaper-o"></i>"Why Bigzen soft"</a>
							<span>Posted on: August 30,2020</span></li>
		
							<li><a href="noticedesc.php"> <i class="fa fa-newspaper-o"></i>"रारा इन्जिनिरिङ्ग कन्सल्टेन्सि "</a>
							  <span>Posted on: August 30,2020</span></li>
		
							  <li><a href="noticedesc.php"> <i class="fa fa-newspaper-o"></i>"Why Bigzen soft"</a>
								<span>Posted on: August 30,2020</span></li>
								<li><a href="noticedesc.php"> <i class="fa fa-newspaper-o"></i>"कर्णाली प्रदेशको पहिलो रिसर्च सेन्टर"</a>
								  <span>Posted on: August 30,2020</span></li>
					  </ul>
					  <button class="btn primary"><a href="noticedesc.php"> See More</a></button>
					</div>
				  </div>
				</div>
		
			  </div>
			</div>
		  </section>
		  	<!-- Message from chairman section end -->
		  <!-- News and Notice section end -->
		
		  <div class="clearfix">
		
		  </div>


		<!-- Our Main Courses Section start -->

		<section class="courses section" id="coursesid">
			<div class="section-title" style="text-align: center;">
				<h2>Our Main Courses</h2>
			</div>
			
			<div class="container">
				
				
				<div class="row">
	
					<!-- courses item start -->
					<div class="courses-item ">
						<div class="courses-item-inner shadow-dark">
						  <div class="courses-img">
							<img src="assets/img/Science and Technology.jpg" alt="">
							<!-- <div class="courseswhat">Building</div> -->
						  </div>
						  <div class="courses-info">
							  <h4 class="courses-title">Science</h4>
							 <div class="readmore">
								 <a href="">Read More</a>
							 </div>
						  </div>
					  </div>
					</div>
					<!-- courses item end -->
					 <!-- courses item start -->
					 <div class="courses-item ">
						<div class="courses-item-inner shadow-dark">
							<div class="courses-img">
							  <img src="assets/img/Science and Technology.jpg" alt="">
							  <!-- <div class="courseswhat">Shopping Mall</div> -->
							</div>
							<div class="courses-info">
								<h4 class="courses-title">Science</h4>
								<div class="readmore">
									<a href="">Read More</a>
								</div>
								
							</div>
						</div>
					  </div>
					  <!-- courses item end -->
		
					   <!-- courses item start -->
					<div class="courses-item">
						<div class="courses-item-inner shadow-dark">
							<div class="courses-img">
							  <img src="assets/img/Science and Technology.jpg" alt="">
							  <!-- <div class="courseswhat">Complex Mall</div> -->
							</div>
							<div class="courses-info">
								<h4 class="courses-title">Science</h4>
								<div class="readmore">
									<a href="">Read More</a>
								</div>
								
							</div>
						</div>
					  </div>
					  <!-- courses item end -->
	
					  <!-- courses item start -->
					<div class="courses-item">
						<div class="courses-item-inner shadow-dark">
							<div class="courses-img">
							  <img src="assets/img/Science and Technology.jpg" alt="">
							  <!-- <div class="courseswhat">Complex Mall</div> -->
							</div>
							<div class="courses-info">
								<h4 class="courses-title">Science</h4>
								<div class="readmore">
									<a href="">Read More</a>
								</div>
								
							</div>
						</div>
					  </div>
					  <!-- courses item end -->
					  	<!-- courses item start -->
					<div class="courses-item ">
						<div class="courses-item-inner shadow-dark">
						  <div class="courses-img">
							<img src="assets/img/Science and Technology.jpg" alt="">
							<!-- <div class="courseswhat">Building</div> -->
						  </div>
						  <div class="courses-info">
							  <h4 class="courses-title">Science</h4>
							 <div class="readmore">
								 <a href="">Read More</a>
							 </div>
						  </div>
					  </div>
					</div>
					<!-- courses item end -->


						<!-- courses item start -->

						<div class="courses-item ">
							<div class="courses-item-inner shadow-dark">
							  <div class="courses-img">
								<img src="assets/img/Science and Technology.jpg" alt="">
								<!-- <div class="courseswhat">Building</div> -->
							  </div>
							  <div class="courses-info">
								  <h4 class="courses-title">Science</h4>
								 <div class="readmore">
									 <a href="">Read More</a>
								 </div>
							  </div>
						  </div>
						</div>
						<!-- courses item end -->
						
				</div>
			</div>
		</section>


		<!-- Our main courses section end -->
       
		
		<!-- Service Sectin start -->


		<section id="service">
			<div class="container">
				<div class="col-lg-10 mx-auto">
				   <div class="services">
					<h2 class="text-center">Our Facilities</h2>
					<p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores explicabo<br> assumenda iusto veniam vero optio iste maiores dicta odit tempora.</p>
				   </div>
				</div>
				
				<div class="row">
					<div class="col-lg-3">
						<div class="service-box">
							<i class="fa fa-desktop"></i>
							<h4 class="title">Computer Lab</h4>
							<p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi unde, in beatae, cum eveniet facilis.</p>
						</div>
					</div>
					

					<div class="col-lg-3">
						<div class="service-box">
							<i class="fa fa-suitcase"></i>
							<h4 class="title">24/7 Electricity</h4>
							<p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi unde, in beatae, cum eveniet facilis.</p>
						</div>
					</div>
					

					<div class="col-lg-3">
						<div class="service-box">
							<i class="fa fa-home"></i>
							<h4 class="title">Infrastructure</h4>
							<p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi unde, in beatae, cum eveniet facilis.</p>
						</div>
					</div>
					
					<div class="col-lg-3">
						<div class="service-box">
							<i class="fa fa-car"></i>
							<h4 class="title">Transportation</h4>
							<p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi unde, in beatae, cum eveniet facilis.</p>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="service-box">
							<i class="fa fa-bed"></i>
							<h4 class="title">Hostel</h4>
							<p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi unde, in beatae, cum eveniet facilis.</p>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="service-box">
							<i class="fa fa-users"></i>
							<h4 class="title">Qualified Teachers</h4>
							<p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi unde, in beatae, cum eveniet facilis.</p>
						</div>
					</div>

					
				</div>
			</div>
		</section>


		<!-- Service section end -->
	   
		
    <!-- Counter section start -->

    <section class="stat" id="stats">

		<h3>Our Achievements</h3>

        <div class="content-box">
            <br><br>
            <div class="container">
                <div class="row text-center">

                    <div class="col-md-4">
                        <div class="stat-items">
                            <i class="fa fa-child"></i>
                            <h2><span class="counter text-center">10000</span> <span>+</span></h2>
                            <p>Students</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="stat-items">
                            <i class="fa fa-trophy"></i>
                            <h2><span class="counter text-center">100</span> <span>+</span></h2>
                            <p>Trophies Won</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="stat-items">
                            <i class="fa fa-graduation-cap"></i>
                            <h2><span class="counter text-center">150</span> <span>+</span></h2>
                            <p>Total Graduates</p>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>

    </section>


    <!-- Counter section end -->
        
     <!-- Testimonials sections start -->
	 <div class="testimonial wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
			<h4>Students Alumini</h4>
			<p>What our passed out students say about their experience with us.</p>
            <div class="row">
                <div class="col-12">
                    <div class="testimonial-slider-nav">
                         <!-- <div class="slider-nav"><img src="assets/img/Santosh Pandey.jpg" alt="Testimonial"></div>
                        <div class="slider-nav"><img src="assets/img/santu.jpg" alt="Testimonial"></div>
                        <div class="slider-nav"><img src="assets/img/Santosh Pandey.jpg" alt="Testimonial"></div>
                        <div class="slider-nav"><img src="assets/img/santu.jpg" alt="Testimonial"></div>  -->
                      
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="testimonial-slider">
                        <div class="slider-item">
                            
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate.
								 Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
								 <h3>Santosh Pandeya</h3>
                            <h4>CEO and Founder Of Bigzen Soft</h4>
                        </div>
                        <div class="slider-item">
                            
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate.
								 Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
								 <h3>Santosh Pandeya</h3>
                            <h4>CEO and Founder Of Bigzen Soft</h4>
                        </div>
						<div class="slider-item">
                            
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate.
								 Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
								 <h3>Santosh Pandeya</h3>
                            <h4>CEO and Founder Of Bigzen Soft</h4>
                        </div>
                        <div class="slider-item">
                            
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate.
								 Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
								 <h3>Santosh Pandeya</h3>
                            <h4>CEO and Founder Of Bigzen Soft</h4>
                        </div>
                       
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
	 <!-- Testimonials sections end -->
        
       
        <!--================ start footer Area  =================-->	
		<footer class="footer-area p_120">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget tp_widgets">
                           <h6 class="footer_title">About Us</h6>
                           <p>
                            United Educational Academy prepares students to understand, contribute to, 
                            and succeed in a rapidly changing society, 
                            and thus make the world a better and more than just a place.
                          </p>
                        </div>
                    </div>

                    
                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget tp_widgets">
                           <h6 class="footer_title">Top Courses</h6>
                            <ul class="list">
                            	<li><a href="#">Diploma Computer</a></li>
                            	<li><a href="#">Forestry</a></li>
                            	<li><a href="#">Diploma Civil</a></li>
                            	<li><a href="#">Isc AG</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget tp_widgets">
                           <h6 class="footer_title">Quick Links</h6>
                            <ul class="list">
                            	<li><a href="#">Job Vacancy</a></li>
                            	<li><a href="#">Notice</a></li>
                            	
                            </ul>
                        </div>
                    </div>
                   
                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget tp_widgets">
                           <h6 class="footer_title">Useful Links</h6>
                            <ul class="list">
                            	<li><a href="#">Ctevt</a></li>
                            	<li><a href="#">NEB</a></li>
                            	
                            </ul>
                        </div>
                    </div>
                   
                </div>
                <div class="row footer-bottom d-flex justify-content-between align-items-center">
                    <p class="col-lg-8 col-md-8 footer-text m-0">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | By dullu college <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="http://www.bigzensoft.com.np/" target="_blank">Bigzen Soft</a>
</p>
                    <div class="col-lg-4 col-md-4 footer-social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-mobile"></i></a>
                        
                    </div>
                </div>
            </div>
			<button id="topBtn"> <i class="fa fa-arrow-up"></i>
        </footer>
			
			
				
	
		<!--================ End footer Area  =================-->
        
        
        
        
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/popper.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/stellar.js"></script>
        <script src="assets/vendors/lightbox/simpleLightbox.min.js"></script>
        <script src="assets/vendors/nice-select/js/jquery.nice-select.min.js"></script>
        <script src="assets/vendors/isotope/imagesloaded.pkgd.min.js"></script>
        <script src="assets/vendors/isotope/isotope.pkgd.min.js"></script>
        <script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
        <script src="assets/vendors/popup/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <script src="assets/vendors/counter-up/jquery.waypoints.min.js"></script>
        <script src="assets/vendors/counter-up/jquery.counterup.js"></script>
        <script src="assets/js/mail-script.js"></script>
		<script src="assets/js/theme.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		<script src="assets/js/slick.min.js"></script>
		<script src="assets/slick/slick.js"></script>
		<script src="assets/js/main.js"></script>
		
		
    </body>
</html>